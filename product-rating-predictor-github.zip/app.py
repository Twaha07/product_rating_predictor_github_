from flask import Flask, render_template, request
import numpy as np
import pickle

app = Flask(__name__)
model = pickle.load(open('model/product_model.pkl', 'rb'))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    price = float(request.form['price'])
    num_reviews = float(request.form['num_reviews'])
    category = int(request.form['category'])

    features = np.array([[price, num_reviews, category]])
    prediction = model.predict(features)[0]

    return render_template('result.html', rating=round(prediction, 2))

if __name__ == '__main__':
    app.run(debug=True)