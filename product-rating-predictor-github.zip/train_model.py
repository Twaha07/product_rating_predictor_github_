import pandas as pd
from sklearn.linear_model import LinearRegression
import pickle

# Sample dataset
data = {
    'price': [100, 200, 150, 250, 300],
    'num_reviews': [50, 100, 80, 120, 200],
    'category': [1, 2, 1, 2, 3],  # Encoded categories
    'rating': [3.5, 4.2, 4.0, 4.5, 5.0]
}

df = pd.DataFrame(data)

# Features and target
X = df[['price', 'num_reviews', 'category']]
y = df['rating']

# Model training
model = LinearRegression()
model.fit(X, y)

# Save the model
with open('model/product_model.pkl', 'wb') as f:
    pickle.dump(model, f)